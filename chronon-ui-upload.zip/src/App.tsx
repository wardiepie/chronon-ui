import React from 'react'
import ChrononUI from './ChrononUI'

export default function App() {
  return <ChrononUI />
}
