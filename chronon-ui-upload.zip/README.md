# Chronon (Chi) — Bouwsteen van Tijd

Interactieve demo die het Chronon (χ/Chi) visualiseert: de natuurlijke tijdeenheid
verkregen uit het aritmetisch–geometrisch gemiddelde (AGM) tussen Plancktijd en de leeftijd
van het universum (~4,83×10^15 s ≈ 153 Myr).

## Gebruik

1. Installeer afhankelijkheden:
   ```bash
   npm install
   ```
2. Start lokaal:
   ```bash
   npm run dev
   ```

© 2025-09-20 Ward Clement B. Vandeplas
